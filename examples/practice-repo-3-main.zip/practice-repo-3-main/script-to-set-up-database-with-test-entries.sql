create table customers(
	customer_id serial primary key,
	first_name varchar(20),
	last_name varchar(20)
);

-- for delete test
insert into customers values(-1,'for','delete');
-- for account create test 
insert into customers values(-2, 'for','create account test');
-- update for update account test
update accounts set balance = 500.00 where account_id = -3; 
-- needed for delete account_test
insert into accounts values(-4,-2,500.00);
-- needed for transfer success test (make sure to add account records first)
update accounts set balance = 500.00 where account_id = -5;
update accounts set balance = 500.00 where account_id = -6;

create table accounts(
	account_id serial primary key,
	customer_id int,
	balance dec(15,2),
	constraint account_fk foreign key (customer_id) references customers(customer_id) on delete cascade
);


