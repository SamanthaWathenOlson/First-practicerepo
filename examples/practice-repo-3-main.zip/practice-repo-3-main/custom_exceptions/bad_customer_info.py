class BadCustomerInfo(Exception):
    pass