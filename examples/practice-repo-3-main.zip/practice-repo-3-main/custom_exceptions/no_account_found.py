class NoAccountFound(Exception):
    pass