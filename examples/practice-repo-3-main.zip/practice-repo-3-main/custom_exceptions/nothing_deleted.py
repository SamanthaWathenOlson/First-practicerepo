class NothingDeleted(Exception):
    pass