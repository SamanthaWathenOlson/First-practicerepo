from unittest.mock import patch

from custom_exceptions.connection_problem import ConnectionProblem
from custom_exceptions.nothing_deleted import NothingDeleted
from data_access_layer.customer_dal.customer_dao_imp import CustomerDAOImp
from entities.customer_class import Customer

customer_dao = CustomerDAOImp()


def test_create_customer_entry_success():
    # create customer object to enter into database
    customer = Customer(0, "Timmy", "Jimmy")
    # pass object into create method
    result_customer = customer_dao.create_customer_entry(customer)
    # check that it has a new id
    assert result_customer.customer_id != 0


def test_delete_customer_entry_success():
    # pass in id of entry to be deleted into delete method
    # remember to make sure customer you are deleting is actually in the database
    result = customer_dao.delete_customer_entry_by_id(-1)
    # check boolean result of delete method
    assert result


@patch("utils.connection_module.connection.cursor")
def test_create_customer_operational_error_caught(mock):
    # try to run create method, have exception raised instead
    try:
        mock.side_effect = ConnectionProblem("Could not connect to the database")
        customer_dao.create_customer_entry(Customer(0,"should not","be added"))
        assert False
    # check that our method catches and raises a new exception and has the proper message
    except ConnectionProblem as e:
        assert str(e) == "Could not connect to the database"


@patch("utils.connection_module.connection.cursor")
def test_delete_customer_operational_error_caught(mock):
    # try to run create method, have exception raised instead
    try:
        mock.side_effect = ConnectionProblem("Could not connect to the database")
        customer_dao.delete_customer_entry_by_id(0)
        assert False
    # check that our method catches and raises a new exception and has the proper message
    except ConnectionProblem as e:
        assert str(e) == "Could not connect to the database"


def test_delete_customer_no_records_changed():
    try:
        customer_dao.delete_customer_entry_by_id(-1000)
        assert False
    except NothingDeleted as e:
        assert str(e) == "No record was deleted"
