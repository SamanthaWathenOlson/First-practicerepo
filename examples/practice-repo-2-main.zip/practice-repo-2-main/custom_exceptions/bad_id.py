class BadId(Exception):
    pass