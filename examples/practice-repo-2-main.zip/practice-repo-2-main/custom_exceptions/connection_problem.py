class ConnectionProblem(Exception):
    pass