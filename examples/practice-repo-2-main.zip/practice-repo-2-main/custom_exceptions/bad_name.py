class BadName(Exception):
    pass